import java.util.Scanner;

public class Q6 {
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        System.out.println("Enter nine-digit number :");
        int numInput=input.nextInt();

        int num;
        num = numInput;

        int d9=num%10;
        num=num/10;

        int d8=num%10;
        num=num/10;

        int d7=num%10;
        num=num/10;

        int d6=num%10;
        num=num/10;

        int d5=num%10;
        num=num/10;

        int d4=num%10;
        num=num/10;

        int d3=num%10;
        num=num/10;

        int d2=num%10;
        num=num/10;

        int d1=num%10;
        num=num/10;

        int d10=(d1*1 + d2*2 + d3*3 + d4*4 + d5*5 + d6*6 + d7*7 + d8*8 + d9*9) % 11;
        if(d10<10)
            System.out.println("Resulting ISBN-10 : " + numInput+ ""+ d10);
        else
            System.out.println("Resulting ISBN-10 : " + numInput+"X");
    }
}
