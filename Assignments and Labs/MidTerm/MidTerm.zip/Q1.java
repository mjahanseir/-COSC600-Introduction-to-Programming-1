import java.util.Scanner;

public class Q1 {
    public static void main(String[] args) {

        Scanner input= new Scanner(System.in);
        System.out.println("Enter a string and two numbers:");

        String strInput=  input.nextLine();
        int num1=input.nextInt();
        int num2=input.nextInt();

        System.out.println(strInput.charAt(num1) + " "+ strInput.charAt(num2));
    }
}
