import java.util.Scanner;

public class Q4 {
    public static void main(String[] args) {

        int randomNumber=(int) Math.round(Math.random()*1000);
        int randomNumber1=randomNumber%10;
        int randomNumber2=(randomNumber/10) %10;
        int randomNumber3=(randomNumber/100) %10;

        Scanner input= new Scanner(System.in);
        System.out.println("Enter three single digit numbers :");
        int in1=input.nextInt();
        int in2=input.nextInt();
        int in3=input.nextInt();

        int numberOfSucess=0;

        if((in1==randomNumber1 ||in1==randomNumber2 ||in1==randomNumber3)&&
                (in2==randomNumber1 ||in2==randomNumber2 ||in2==randomNumber3)&&
                (in3==randomNumber1 ||in3==randomNumber2 ||in3==randomNumber3)) {
            System.out.println("Exact Match!");
        }else {
            if (in1 == randomNumber1 || in1 == randomNumber2 || in1 == randomNumber3) {
                numberOfSucess++;
            }
            if (in2 == randomNumber1 || in2 == randomNumber2 || in2 == randomNumber3) {
                numberOfSucess++;
            }
            if (in3 == randomNumber1 || in3 == randomNumber2 || in3 == randomNumber3) {
                numberOfSucess++;
            }
        }
        if (numberOfSucess == 2)
            System.out.println("Close: 2 correct!");
        else if(numberOfSucess<2)
            System.out.println("Oops. That wasn’t a very good guess!");
    }
}
