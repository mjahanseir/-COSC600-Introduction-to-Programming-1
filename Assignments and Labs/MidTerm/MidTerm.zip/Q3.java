import java.util.Scanner;

public class Q3 {
    public static void main(String[] args) {

        Scanner input= new Scanner(System.in);
        System.out.println("Enter 4-digit number :");
        int numinput=input.nextInt();

        int num=numinput;

        int num1=num%10;
        num=num/10;

        int num2=num%10;
        num=num/10;

        int num3=num%10;
        num=num/10;

        int num4=num%10;
        num=num/10;

        if(num1==num4 && num2==num3)
            System.out.println(numinput + " is palindrome");
        else
            System.out.println(numinput + " is not palindrome");
    }
}
