import java.util.Scanner;

public class Q5 {
    public static void main(String[] args) {

        Scanner input= new Scanner(System.in);

        System.out.println("Enter year e a year between 2000 and 2100 :");
        int year=input.nextInt();

        int yearCalc=(year%12);


        String nameYear="";

        switch(yearCalc){
            case 8 :
                nameYear="dragon";
                break;
            case 9 :
                nameYear="snake";
                break;
            case 10 :
                nameYear="horse";
                break;
            case 11 :
                nameYear="goat";
                break;
            case 0 :
                nameYear="monkey";
                break;
            case 1 :
                nameYear="rooster";
                break;
            case 2 :
                nameYear="dog";
                break;
            case 3 :
                nameYear="pig";
                break;
            case 4:
                nameYear="rat";
                break;
            case 5 :
                nameYear="ox";
                break;
            case 6 :
                nameYear="tiger";
                break;
            case 7 :
                nameYear="rabbit";
                break;
            default:
                nameYear="Invalid";
        }

        System.out.println(year + " corresponds to from the \"" + nameYear + "\" Chinese zodiac");
    }
}
